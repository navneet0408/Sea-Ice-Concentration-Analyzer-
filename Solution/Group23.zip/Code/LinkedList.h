/*
 * LinkedList.h
 *
 *  Created on: Aug 29, 2015
 *      Author: navneet
 */

#ifndef LINKEDLIST_H_
#define LINKEDLIST_H_

#include "DataTypes.h"

void add( Node **head, Node *item);
Node *del( Node **head);

#endif /* LINKEDLIST_H_ */
