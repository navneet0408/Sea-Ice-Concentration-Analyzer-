*****************************************************************************
************************ CEN-501: COMPUTER SYSTEMS II ***********************
*****************************************************************************

1. The code can be compiled using the following command:
	gcc —O3 -o SeaIceConc Graph.c LinkedList.c Main.c ParseData.c -lm
2. The application can be executed using the following command:
	./SeaIceConc
3. GCC version 4.8.2-19 was used to compile the application. Previous versions of GCC throw an error upon compilations.
4. The output files used for the plotting of histogram are included with the report.